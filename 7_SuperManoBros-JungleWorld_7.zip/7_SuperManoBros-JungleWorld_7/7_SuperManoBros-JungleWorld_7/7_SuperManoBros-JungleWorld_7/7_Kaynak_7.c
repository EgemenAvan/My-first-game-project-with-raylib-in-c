#include "raylib.h"

#define screenwidht 1400 
#define screenheight 700 
#define gravity 0.5f
#define jumpforce 15   
#define maxentites 22 // Track and enemies 
#define maxgolds 20

// Images of the game
typedef struct {
    Rectangle rect;
    Color color;
} Platform;

typedef struct {
    Vector2 position;
    Texture2D texture;
} Gold;
Gold golds[maxgolds];

typedef struct {
    Rectangle rect;
    float speed;
    bool moveright;
    Vector2 startpos;
    Vector2 endpos;
    Texture2D texture;
} Entity;

Texture2D background;
Texture2D character;
Texture2D flag;
Texture2D tower;
Texture2D gold;
Platform platforms[maxentites];
Entity enemies[maxentites];
Vector2 characterPosition;
Vector2 characterSpeed;
bool jumpcontrol;

Camera2D camera;

int totalGold;      // Total number of gold coins
int collectedGold;  // Number of gold collected

bool WinConditionMet(Vector2 MarioPosition) {
    // If the right edge is reached, win the game
    return MarioPosition.x > screenwidht + 2000;
}

bool LoseConditionMet(Vector2 MarioPosition) {
    // If the character hits the enemy, lose the game
    for (int i = 0; i < maxentites; i++) {
        if (CheckCollisionRecs((Rectangle) { MarioPosition.x, MarioPosition.y, character.width, character.height }, enemies[i].rect)) {
            return true;
        }
    }
    return false;
}

void InitGame() {
    // Upload background and character
    background = LoadTexture("background.png");
    character = LoadTexture("Mario.png");
    gold = LoadTexture("gold.png");
    // Load end flag
    flag = LoadTexture("flag.png");
    tower = LoadTexture("tower.png");

    // Adjust character position and speed
    characterPosition = (Vector2){ 100, screenheight - character.height };
    characterSpeed = (Vector2){ 0, 0 };
    jumpcontrol = false;

    // Create tracks
    platforms[0] = (Platform){ (Rectangle) { -10000, screenheight - 50, screenwidht + 1000000, 50 }, DARKGRAY };
    platforms[1] = (Platform){ (Rectangle) { 400, screenheight - 150, 200, 30 }, DARKGRAY };
    platforms[2] = (Platform){ (Rectangle) { 800, screenheight - 250, 200, 30 }, DARKGRAY };
    platforms[3] = (Platform){ (Rectangle) { 100, screenheight - 350, 200, 30 }, DARKGRAY };
    platforms[4] = (Platform){ (Rectangle) { 600, screenheight - 450, 200, 30 }, DARKGRAY };
    platforms[5] = (Platform){ (Rectangle) { 1200, screenheight - 300, 200, 30 }, DARKGRAY };
    platforms[6] = (Platform){ (Rectangle) { 1800, screenheight - 500, 400, 30 }, DARKGRAY };
    platforms[7] = (Platform){ (Rectangle) { 1600, screenheight - 300, 50, 30 }, DARKGRAY };
    platforms[8] = (Platform){ (Rectangle) { 2350, screenheight - 400, 50, 30 }, DARKGRAY };
    platforms[9] = (Platform){ (Rectangle) { 1700, screenheight - 75, 50, 30 }, DARKGRAY };
    platforms[10] = (Platform){ (Rectangle) { 1800, screenheight - 150, 50, 30 }, DARKGRAY };
    platforms[11] = (Platform){ (Rectangle) { 2870, screenheight - 300, 30, 500 }, DARKGRAY };
    platforms[12] = (Platform){ (Rectangle) { 2840, screenheight - 250, 30, 500 }, DARKGRAY };
    platforms[13] = (Platform){ (Rectangle) { 2810, screenheight - 200, 30, 500 }, DARKGRAY };
    platforms[14] = (Platform){ (Rectangle) { 2780, screenheight - 150, 30, 500 }, DARKGRAY };
    platforms[15] = (Platform){ (Rectangle) { 2750, screenheight - 100, 30, 500 }, DARKGRAY };
    platforms[16] = (Platform){ (Rectangle) { 2900, screenheight - 350, 100, 500 }, DARKGRAY };
    platforms[17] = (Platform){ (Rectangle) { 3000, screenheight - 300, 30, 500 }, DARKGRAY };
    platforms[18] = (Platform){ (Rectangle) { 3030, screenheight - 250, 30, 500 }, DARKGRAY };
    platforms[19] = (Platform){ (Rectangle) { 3060, screenheight - 200, 30, 500 }, DARKGRAY };
    platforms[20] = (Platform){ (Rectangle) { 3090, screenheight - 150, 30, 500 }, DARKGRAY };
    platforms[21] = (Platform){ (Rectangle) { 3120, screenheight - 100, 30, 500 }, DARKGRAY };


    //Create and adjust enemies
    enemies[0] = (Entity){ (Rectangle) { 400, screenheight - 200, 40, 20 }, 100.0f, false, { 400, screenheight + 250 }, { 550, screenheight + 250 }, LoadTexture("enemies.png") };
    enemies[1] = (Entity){ (Rectangle) { 600, screenheight - 500, 40, 20 }, 100.0f, false, { 600, screenheight + 50 }, { 750, screenheight + 50 }, LoadTexture("enemies.png") };
    enemies[2] = (Entity){ (Rectangle) { 1100, screenheight - 450, 40, 20 }, 100.0f, true, { 1100, screenheight + 100 }, { 1400, screenheight + 100 }, LoadTexture("enemies.2.png") };
    enemies[3] = (Entity){ (Rectangle) { 1000, screenheight - 100, 40, 20 }, 100.0f, true, { 1000, screenheight + 100 }, { 1200, screenheight + 100 }, LoadTexture("enemies.3.png") };
    enemies[4] = (Entity){ (Rectangle) { 2200, screenheight + 250, 40, 20 }, 100.0f, true, { 2300, screenheight + 250 }, { 2700, screenheight + 100 }, LoadTexture("enemies.3.png") };
    enemies[5] = (Entity){ (Rectangle) { 2000, screenheight - 100, 40, 20 }, 150.0f, false, { 2000, screenheight + 200 }, { 2200, screenheight + 200 }, LoadTexture("enemies.3.png") };
    enemies[6] = (Entity){ (Rectangle) { 1800, screenheight - 650, 40, 20 }, 150.0f, false, { 1800, screenheight + 200 }, { 2100, screenheight + 200 }, LoadTexture("enemies.2.png") };

    // Create camera
    camera.target = (Vector2){ screenwidht / 2, screenheight / 2 };
    camera.offset = (Vector2){ screenwidht / 2, screenheight / 2 };
    camera.rotation = 0.0f;
    camera.zoom = 1.0f;

    // Starts gold
    totalGold = maxgolds;
    collectedGold = 0;
}

void InitGolds() {
    golds[0] = (Gold){ (Vector2) { 800, screenheight - 310 }, LoadTexture("gold.png") };
    golds[1] = (Gold){ (Vector2) { 400, screenheight - 210 }, LoadTexture("gold.png") };
    golds[2] = (Gold){ (Vector2) { 100, screenheight - 410 }, LoadTexture("gold.png") };
    golds[3] = (Gold){ (Vector2) { 600, screenheight - 510 }, LoadTexture("gold.png") };
    golds[4] = (Gold){ (Vector2) { 1200, screenheight - 360 }, LoadTexture("gold.png") };
    golds[5] = (Gold){ (Vector2) { 1800, screenheight - 560 }, LoadTexture("gold.png") };
    golds[6] = (Gold){ (Vector2) { 1600, screenheight - 460 }, LoadTexture("gold.png") };
    golds[7] = (Gold){ (Vector2) { 2350, screenheight - 460 }, LoadTexture("gold.png") };
    golds[8] = (Gold){ (Vector2) { 2350, screenheight - 460 }, LoadTexture("gold.png") };
    golds[9] = (Gold){ (Vector2) { 2170, screenheight - 560 }, LoadTexture("gold.png") };
    golds[10] = (Gold){ (Vector2) { 2930, screenheight - 640 }, LoadTexture("gold.png") };
    golds[11] = (Gold){ (Vector2) { 2905, screenheight - 600 }, LoadTexture("gold.png") };
    golds[12] = (Gold){ (Vector2) { 2955, screenheight - 600 }, LoadTexture("gold.png") };
    golds[13] = (Gold){ (Vector2) { 2880, screenheight - 560 }, LoadTexture("gold.png") };
    golds[14] = (Gold){ (Vector2) { 2930, screenheight - 560 }, LoadTexture("gold.png") };
    golds[15] = (Gold){ (Vector2) { 2980, screenheight - 560 }, LoadTexture("gold.png") };
    golds[16] = (Gold){ (Vector2) { 2855, screenheight - 520 }, LoadTexture("gold.png") };
    golds[17] = (Gold){ (Vector2) { 2905, screenheight - 520 }, LoadTexture("gold.png") };
    golds[18] = (Gold){ (Vector2) { 2955, screenheight - 520 }, LoadTexture("gold.png") };
    golds[19] = (Gold){ (Vector2) { 3005, screenheight - 520 }, LoadTexture("gold.png") };
}

void DrawGolds() {
    for (int i = 0; i < maxgolds; i++) {
        DrawTexture(golds[i].texture, golds[i].position.x, golds[i].position.y, WHITE);
    }
}

void UpdateGame() {
    // Character movement update
    if (IsKeyDown(KEY_RIGHT)) {
        characterSpeed.x = 5;
    }
    else if (IsKeyDown(KEY_LEFT)) {
        characterSpeed.x = -5;
    }
    else {
        characterSpeed.x = 0;
    }

    // Jump function
    if (IsKeyPressed(KEY_SPACE) && !jumpcontrol) {
        characterSpeed.y = -jumpforce;
        jumpcontrol = true;
    }

    // Gravity effect
    characterSpeed.y += gravity;

    // Controlling the character's collision with tracks
    for (int i = 0; i < maxentites; i++) {
        if (CheckCollisionRecs((Rectangle) { characterPosition.x, characterPosition.y, character.width, character.height },
            platforms[i].rect) && characterSpeed.y > 0) {
            characterSpeed.y = 0;
            characterPosition.y = platforms[i].rect.y - character.height;
            jumpcontrol = false;
        }
    }
    // Prevent the character from moving further left from the starting point
    if (characterPosition.x < 100) {
        characterPosition.x = 100;
    }

    // Update character position
    characterPosition.x += characterSpeed.x;
    characterPosition.y += characterSpeed.y;

    // Making the camera follow the character's x position
    camera.target.x = characterPosition.x;

    // Update enemies' movement
    for (int i = 0; i < maxentites; i++) {
        if (enemies[i].moveright) {
            enemies[i].rect.x += enemies[i].speed * GetFrameTime();
            if (enemies[i].rect.x > enemies[i].endpos.x) {
                enemies[i].moveright = false;
            }
        }
        else {
            enemies[i].rect.x -= enemies[i].speed * GetFrameTime();
            if (enemies[i].rect.x < enemies[i].startpos.x) {
                enemies[i].moveright = true;
            }
        }
    }
    // Controlling whether the character steps on enemies' heads
    for (int i = 0; i < maxentites; i++) {
        Rectangle characterFeet = { characterPosition.x, characterPosition.y + character.height, character.width, 5 };
        Rectangle enemyHead = { enemies[i].rect.x, enemies[i].rect.y - 5, enemies[i].rect.width, 10 };

        if (CheckCollisionRecs(characterFeet, enemyHead)) {
            // The character stepped on the enemy's head
            enemies[i].speed = 0; // Stop enemy horizontal movement
            enemies[i].rect.y += 5; // Move the enemy slightly lower 

            // Destruction of the enemy
            enemies[i].rect.x = -100000000; // Enemy goes off screen

        }
    }
    // Control to prevent the character's head from entering the platform
    for (int i = 0; i < maxentites; i++) {
        if (CheckCollisionRecs((Rectangle) { characterPosition.x, characterPosition.y, character.width, character.height },
            platforms[i].rect) && characterSpeed.y < 0) {
            characterSpeed.y = 0;
            characterPosition.y = platforms[i].rect.y + platforms[i].rect.height;
        }
    }

    // Controlling the character to collect gold coins
    for (int i = 0; i < maxgolds; i++) {
        if (CheckCollisionRecs((Rectangle) { characterPosition.x, characterPosition.y, character.width, character.height }, (Rectangle) { golds[i].position.x, golds[i].position.y, gold.width, gold.height })) {
            if (golds[i].texture.id != 0) {
                collectedGold++;
                golds[i].texture = (Texture2D){ 0 };
            }
        }
    }
}

void DrawGame() {
    BeginDrawing();

    ClearBackground(RAYWHITE);

    // start camera
    BeginMode2D(camera);

    // Drawing the background
    DrawTexture(background, 0, 0, WHITE);
    // Redraw the background on the left
    DrawTexture(background, -background.width, 0, WHITE);

    // Drawing tracks and enemies
    for (int i = 0; i < maxentites; i++) {
        if (i < 22) {
            DrawRectangleRec(platforms[i].rect, platforms[i].color);
        }
        DrawTextureEx(enemies[i].texture, (Vector2) { enemies[i].rect.x, enemies[i].rect.y }, 0.0f, 0.05f, WHITE);
    }

    // drawing the character
    DrawTexture(character, characterPosition.x, characterPosition.y, WHITE);

    // Drawing the flag and tower
    DrawTexture(flag, screenwidht + 2000, screenheight - 448, WHITE);
    DrawTexture(tower, screenwidht - 1900, screenheight - 600, WHITE);

    // Drawing gold
    DrawGolds();

    // Finish camera
    EndMode2D();

    // Drawing the gold collection counter
    DrawText(TextFormat("GOLD %d ", collectedGold), 20, 20, 20, BLACK);

    EndDrawing();
}

void WhiteScreen(int timeInSeconds, const char* message, Texture2D backgroundTexture) {
    float timer = 0;

    while (timer < timeInSeconds) {
        BeginDrawing();
        // Draw background
        DrawTexture(backgroundTexture, 0, 0, WHITE);
        // Print message
        DrawText(message, screenwidht / 2 - MeasureText(message, 40) / 2, screenheight / 2 - 20, 40, BLACK);
        // Print additional message based on related message
        if (strcmp(message, "Game Over! You Lost!") == 0) {
            DrawText(TextFormat("Restarting in %.0f seconds...", timeInSeconds - timer), screenwidht / 2 - MeasureText(TextFormat("Restarting in %.0f seconds...", timeInSeconds - timer), 20) / 2, screenheight / 2 + 20, 20, BLACK);
        }
        else if (strcmp(message, "Congratulations! You Win!") == 0) {
            DrawText(TextFormat("Closing in %.0f seconds...", timeInSeconds - timer), screenwidht / 2 - MeasureText(TextFormat("Closing in %.0f seconds...", timeInSeconds - timer), 20) / 2, screenheight / 2 + 20, 20, BLACK);
        }
        EndDrawing();
        timer += GetFrameTime();
    }
}

int main() {
    InitWindow(screenwidht, screenheight, "Super Mano Bros-Jungle World");

    // Starting a game
    InitGame();
    InitGolds();



    SetTargetFPS(60);
    // Adding start button
    bool startGame = false;
    Texture2D menuBackground;
    menuBackground = LoadTexture("menubackground.png");

    // Install Game Over and You Win backgrounds
    Texture2D gameOverBackground = LoadTexture("game_over_background.png");
    Texture2D youWinBackground = LoadTexture("you_win_background.png");

    while (!startGame && !WindowShouldClose()) {
        // Update entries
        // ...

        // Drawing cycle
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Make the menu background red
        DrawTexture(menuBackground, 0, 0, WHITE);

        // "Super Mano Bros" caption
        DrawText("Super Mano Bros", screenwidht / 2 - MeasureText("Super Mano Bros", 60) / 2, screenheight / 4, 60, BLACK);

        // Start button
        Rectangle buttonBounds = { (float)screenwidht / 2 - 100, (float)screenheight / 2 - 30, 200, 60 };
        DrawRectangleRec(buttonBounds, LIGHTGRAY);
        DrawText("Start Game", (int)buttonBounds.x + 20, (int)buttonBounds.y + 15, 30, BLACK);

        // Get mouse state
        Vector2 mousePosition = GetMousePosition();

        // Mouse click control
        if (CheckCollisionPointRec(mousePosition, buttonBounds) && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
            startGame = true; // Game is starting
        }

        EndDrawing();
    }

    // Game loop
    while (!WindowShouldClose()) {
        // Game update
        UpdateGame();

        // Game drawing
        DrawGame();

        // Check if the game was won or lost
        if (WinConditionMet(characterPosition)) {
            WhiteScreen(5, "Congratulations! You Win!", youWinBackground);
            break;
        }


        if (LoseConditionMet(characterPosition)) {
            WhiteScreen(5, "Game Over! You Lost!", gameOverBackground);
            // Start the game from the beginning
            InitGame();
            InitGolds();
        }
    }


    CloseWindow();
    return 0;
}
